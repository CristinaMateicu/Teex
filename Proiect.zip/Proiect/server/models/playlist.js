const { DataTypes } = require("sequelize");
const sequelize = require("../sequelize");

const Playlist = sequelize.define("Playlist", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  description: {
    type: DataTypes.STRING,
    validate:{len:[3,25]},
  },
  createDate: {
    type: DataTypes.DATE,
  },
});

module.exports = Playlist;
