const { DataTypes } = require("sequelize");
const sequelize = require("../sequelize");

const Song = sequelize.define("Song", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: {
    type: DataTypes.STRING,
    validate:{len:[5,25]},
  },
  url: {
    type: DataTypes.STRING,
    validate:{isUrl:true},
  },
   style: {
    type: DataTypes.ENUM,
    allowNull: false,
    values: ["POP", "ROCK", "ALTERNATIVE"],
  },
});

module.exports = Song;
