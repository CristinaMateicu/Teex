const Playlist = require("../models/playlist"); 
const playlistRouter = require("express").Router();
const { Op } = require("sequelize");
const Song = require("../models/song");


playlistRouter.route("/playlists").get(async (req, res) => {
  try {
    const playlists= await Playlist.findAll();
    return res.status(200).json(playlists);
  } catch (e) {
    return res.status(500).json(e);
  }
});
app.get("/playlistSorted", async (req, res, next) => {
  try {
   
    const { sortBy } = req.query;
    let playlist = await Company.findAll({
          order: sortBy ? [[sortBy, "ASC"]] : undefined,
    });
    return res.status(200).json(playlist);
  }catch(err){
    next(err);
  }
});
app.get("/paginare", async (req, res) => {
  try{

  const query={}

  const page=req.query.page
  const limit=req.query.limit

  const startIndex=(page -1)* limit 
  const endIndex=page*limit

  const playlist=await Playlist.findAll(query);
  const finalPlaylist=playlist.slice(startIndex, endIndex)
 
  return res.status(200).json(finalPlaylist);
  }
  catch(err){
      return res.status(500).json(err);
  }
})



playlistRouter.route("/playlistsFiltered").get(async (req, res) => {
  try {
    const { descriptionChosen } = req.query;
    const { createDateChosen } = req.query;
    const { sortBy } = req.query;
    let playlists= await Playlist.findAll({
      where: [
        descriptionChosen
          ? {
              description: {
                [Op.like]: descriptionChosen,
              },
            }
          : undefined,
        createDateChosen
          ? {
              createDate: {
                [Op.gt]: createDateChosen,
              },
            }
          : undefined,
      ],

      
    });

    return res.status(200).json(playlists);
  } catch (e) {
    return res.status(500).json(e);
  }
});



playlistRouter.route("/importPlaylists").post(async (req, res) => {
  try {
    for (let m of req.body) {
      const playlist= await Playlist.create({
        
        description: m.description,
        createDate: m.createDate,
      });
      console.log(playlist);
      for (let c of m.songs) {
        const song= await Song.create({
          title: c.title,
          url: c.url,
          style: c.style,
          idPlaylist: playlist.id,
        });
      }
    }
    return res.status(200).json({ message: "imported successfully" });
  } catch (e) {
    return res.status(500).json(e);
  }
});



playlistRouter.route("/exportedPlaylists").get(async (req, res) => {
  try {
    const result = [];
    for (let m of await Playlist.findAll()) {
      const playlist= {
        id: m.id,
      
        description: m.description,
        createDate: m.createDate,
        songs: [],
      };
      for (let c of await m.getSongs()) {
        playlist.songs.push({
          title: c.title,
          url: c.url,
          style: c.style,
          idPlaylist: playlist.id,
        });
      }

      result.push(playlist);
    }

    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(404).json({ message: "playlistsnot found" });
    }
  } catch (e) {
    return res.status(500).json(e);
  }
});



playlistRouter.route("/playlists/:idPlaylist").get(async (req, res) => {
  try {
    const playlist= await Playlist.findAll({
      where: {
        id: req.params.idPlaylist,
      },
    });

    if (Object.keys(playlist).length !== 0) {
      return res.status(200).json(playlist);
    } else {
      return res.status(404).json({ message: "playlistnot found" });
    }
  } catch (e) {
    return res.status(500).json(e);
  }
});



playlistRouter.route("/playlists").post(async (req, res) => {
  try {
    const newplaylis= await Playlist.create({
      
      description: req.body.description,
      createDate: req.body.createDate,
    });
    return res.status(200).json(newPlaylist);
  } catch (e) {
    return res.status(500).json(e);
  }
});



playlistRouter.route("/playlists/:idPlaylist").put(async (req, res) => {
  try {
    let playlis= await Playlist.findAll({
      where: {
        id: req.params.idPlaylist,
      },
    });
    if (Object.keys(playlist).length !== 0) {
      playlis= await Playlist.update(
        {
          
          description: req.body.description,
          createDate: req.body.createDate,
        },
        {
          where: {
            id: req.params.idPlaylist,
          },
        }
      );
      return res.status(200).json({ message: "playlisupdated successfully" });
    } else {
      return res.status(404).json({ message: "playlisnot found" });
    }
  } catch (e) {
    return res.status(500).json(e);
  }
});



playlistRouter.route("/playlists/:idPlaylist").delete(async (req, res) => {
  try {
    let playlist = await Playlist.findAll({
      where: {
        id: req.params.idPlaylist,
      },
    });
    if (Object.keys(playlist).length !== 0) {
      playlist = await Playlist.destroy({
        where: {
          id: req.params.idPlaylist,
        },
      });

      return res.status(200).json({ message: "playlist was deleted" });
    } else {
      return res.status(404).json({ message: "playlist not found" });
    }
  } catch (e) {
    return res.status(500).json(e);
  }
});

module.exports = playlistRouter;
