const Song = require("../models/song");
const Playlist = require("../models/playlist");
const songRouter = require("express").Router();



songRouter.route("/playlists/:idPlaylist/songs").get(async (req, res) => {
  try {
    const songs = await Song.findAll({
      where: {
        idPlaylist: req.params.idPlaylist,
      },
    });

    return res.status(200).json(songs);
  } catch (e) {
    return res.status(500).json(e);
  }
});



songRouter
  .route("/playlists/:idPlaylist/songs/:idSong")
  .get(async (req, res) => {
    try {
      const song = await Song.findAll({
        where: {
          id: req.params.idSong,
          idPlaylist: req.params.idPlaylist,
        },
      });
      return res.status(200).json(song);
    } catch (e) {
      return res.status(500).json(e);
    }
  });



songRouter
  .route("/playlists/:idPlaylist/songs")
  .post(async (req, res) => {
    try {
      const newSong = await Song.create({
        title: req.body.title,
        url: req.body.url,
        style: req.body.style,
        idPlaylist: req.params.idPlaylist,
      });
      return res.status(200).json(newSong);
    } catch (e) {
      return res.status(500).json(e);
    }
  });



songRouter
  .route("/playlists/:idPlaylist/songs/:idSong")
  .put(async (req, res) => {
    try {
      let song = await Song.findAll({
        where: {
          id: req.params.idSong,
          idPlaylist: req.params.idPlaylist,
        },
      });
      if (Object.keys(song).length !== 0) {
        song = await Song.update(
          {
            title: req.body.title,
        url: req.body.url,
        style: req.body.style,
          },
          {
            where: {
              id: req.params.idSong,

              idPlaylist: req.params.idPlaylist,
            },
          }
        );
        return res
          .status(200)
          .json({ message: "song updated successfully" });
      } else {
        return res.status(404).json({ message: "song not found" });
      }
    } catch (e) {
      return res.status(500).json(e);
    }
  });



songRouter
  .route("/playlists/:idPlaylist/songs/:idSong")
  .delete(async (req, res) => {
    try {
      let song = await Song.findAll({
        where: {
          id: req.params.idSong,
          idPlaylist: req.params.idPlaylist,
        },
      });

      if (Object.keys(song).length !== 0) {
        song = await Song.destroy({
          where: {
            id: req.params.idSong,
            idPlaylist: req.params.idPlaylist,
          },
        });
        return res.status(200).json({ message: "song was deleted" });
      } else {
        return res.status(404).json({ message: "song not found" });
      }
    } catch (e) {
      return res.status(500).json(e);
    }
  });

module.exports = songRouter;
